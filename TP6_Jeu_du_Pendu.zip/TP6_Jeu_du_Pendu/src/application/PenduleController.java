package application;

import java.util.HashSet;
import java.util.Set;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;

public class PenduleController {
	Set<Lettre> mot;
	StringBuffer chaineTrouvee;
	String motTire;
	int nbrTry = 0;
	boolean gagne = false;

	@FXML
	private TextField afficherSaisie;

	@FXML
	private ImageView img;

	@FXML
	private Text lettreDejaTire;

	@FXML
	private TextField saisie;

	@FXML
	void actionValiderLettre(ActionEvent event) throws Exception {

		char lettreEntre = saisie.getText().charAt(0);
		if (saisie.getText() == null)
			throw new Exception();
		else {
			Lettre l = new Lettre(lettreEntre, motTire);
			if (mot.contains(l)) {
				for (int i = 0; i < mot.size(); i++) {
					chaineTrouvee.setCharAt(l.positions.get(i), lettreEntre);
					afficherSaisie.setText(chaineTrouvee.toString());
					if(chaineTrouvee.toString().equals(motTire)) {
						lettreDejaTire.setText("GG");
						lettreDejaTire.setVisible(true);
						initialize();
					}
				}
			} else {
				if (nbrTry <= 7) {
					nbrTry++;
					img.setImage(new Image(
							"file:///C:/Users/gregn/OneDrive/Documents/3IL/I1/SEMESTRE%201/JAVA%20AVANCEE/TP6/src/application/images/pendu_"
									+ nbrTry + ".jpg"));
				}
				else
					initialize();

			}

		}


	}

	@FXML
	private void initialize() {
		chaineTrouvee = new StringBuffer();
		mot = new HashSet<Lettre>();
		img.setImage(new Image(
				"file:///C:/Users/gregn/OneDrive/Documents/3IL/I1/SEMESTRE%201/JAVA%20AVANCEE/TP6/src/application/images/pendu_0.jpg"));
		String[] mots = { "maman", "papa", "tata", "tonton", "papi" };
		motTire = mots[1];
		for (int i = 0; i < motTire.length(); i++) {
			mot.add(new Lettre(motTire.charAt(i), motTire));
			chaineTrouvee.append('_');
			afficherSaisie.setText(chaineTrouvee.toString());
		}

	}

}
